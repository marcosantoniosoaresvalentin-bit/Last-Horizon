extends RefCounted
## Itens do jogo e receitas de craft.
##
## Cada item tem nome, peso (kg por unidade), categoria e uma descrição curta.
## As receitas "de mão" são poucas: o craft de verdade vai ser feito nas bancadas.

const ITENS := {
	"machado": {"nome": "Machado de Pedra", "kg": 1.6, "cat": "Ferramentas",
		"desc": "Corta árvores. Equipe na mochila e chegue perto do tronco.", "ferramenta": true, "dur": 400},
	"cavadeira": {"nome": "Cavadeira de Pedra", "kg": 2.2, "cat": "Ferramentas",
		"desc": "Cava buracos em qualquer lugar. Cavando no mesmo lugar o buraco fica mais fundo.", "ferramenta": true, "dur": 300},
	"serra": {"nome": "Serra de Pedra", "kg": 1.4, "cat": "Ferramentas",
		"desc": "Lâmina de pedra com dentes amarrada num cabo comprido, com pegador nas duas pontas. Corta devagar e gasta rápido, mas tira peças finas da tora (a rodela) que o machado não consegue.",
		"ferramenta": true, "dur": 120},
	"pa": {"nome": "Pá de Pedra", "kg": 2.6, "cat": "Ferramentas",
		"desc": "Lâmina larga de pedra amarrada num cabo comprido. Cava buracos largos onde dá para entrar, de qualquer fundura. A pá enche de terra: leve até onde quiser e jogue fora.",
		"ferramenta": true, "dur": 350},
	"enxada": {"nome": "Enxada de Pedra", "kg": 2.3, "cat": "Ferramentas",
		"desc": "Lâmina larga de pedra amarrada atravessada num cabo comprido. Mistura a terra com água e fibra para fazer barro.", "ferramenta": true, "dur": 160},
	"pedra_enxada": {"nome": "Lâmina de Enxada", "kg": 1.1, "cat": "Recursos",
		"desc": "Pedra larga e chata, com fio quase reto: vira a enxada no craft (com galho e cipó)."},
	"pedra_pa": {"nome": "Lâmina de Pá", "kg": 1.3, "cat": "Recursos",
		"desc": "Pedra trabalhada larga e fina, arredondada na frente. Feita modelando pedra."},
	"lamina_serra": {"nome": "Lâmina de Serra", "kg": 0.4, "cat": "Recursos",
		"desc": "Pedra trabalhada, comprida e fina, com dentes lascados num lado. Vai ser feita na mesa de trabalhar pedra."},
	"pedra_machado": {"nome": "Pedra de Machado", "kg": 0.9, "cat": "Recursos",
		"desc": "Pedra trabalhada com fio, do formato da cabeça do machado. Vai ser feita na mesa de trabalhar pedra."},
	"pedra_cavadeira": {"nome": "Lâmina de Cavadeira", "kg": 1.0, "cat": "Recursos",
		"desc": "Pedra trabalhada larga e chata, como uma pá. Vai ser feita na mesa de trabalhar pedra."},
	"forquilha": {"nome": "Forquilha", "kg": 1.2, "cat": "Construção",
		"desc": "Cavalete em X de galhos amarrados com cipó. COLOCAR põe no chão onde você escolher; duas forquilhas seguram uma tora para trabalhar.", "colocar": true},
	"argila": {"nome": "Argila", "kg": 1.0, "cat": "Recursos", "desc": "Barro da beira das lagoas."},
	"semente": {"nome": "Semente de Cedrinho", "kg": 0.002, "cat": "Recursos", "desc": "Plante em terra boa: brota em uns 100 dias."},
	"pedra": {"nome": "Pedra", "kg": 0.8, "cat": "Recursos", "desc": "Pedra solta do chão. USAR põe ela na mão: perto de outra pedra no chão dá para bater e modelar as pedras das ferramentas."},
	"galho": {"nome": "Galho", "kg": 0.5, "cat": "Recursos", "desc": "Galho reto e firme."},
	"cipo": {"nome": "Cipó-titica", "kg": 0.15, "cat": "Recursos", "desc": "Raiz aérea da titica: forte e flexível. Serve para amarrar, cestos e cordas."},
	"cipo_trancado": {"nome": "Cipó Trançado", "kg": 0.4, "cat": "Recursos",
		"desc": "Três raízes de titica trançadas: bem mais forte. É a alça do balde e vai servir para muitas outras coisas."},
	"rodela": {"nome": "Rodela", "kg": 2.5, "cat": "Recursos",
		"desc": "Fatia fina cortada da ponta da tora apoiada nas forquilhas. É o fundo do balde."},
	"ponta_pedra": {"nome": "Ponta de Pedra", "kg": 0.25, "cat": "Recursos",
		"desc": "Pedra lascada grossa atrás e com a ponta bem aguda. Amarrada num cabo vira o furador."},
	"furador": {"nome": "Furador de Pedra", "kg": 0.6, "cat": "Ferramentas",
		"desc": "Ponta de pedra amarrada com cipó num cabo de galho. Encostada na madeira e batida com a marreta, abre o furo para o pino.", "ferramenta": true, "dur": 120},
	"lamina_faca": {"nome": "Lâmina de Faca", "kg": 0.15, "cat": "Recursos",
		"desc": "Lasca de pedra comprida e fina, com fio dos dois lados e ponta aguda. Amarrada num cabo vira a faca."},
	"faca": {"nome": "Faca de Pedra", "kg": 0.3, "cat": "Ferramentas",
		"desc": "Lâmina de pedra amarrada com cipó num cabo de galho. Corta o talo das folhas de palmeira. Batida torta, a lâmina quebra.", "ferramenta": true, "dur": 40},
	"vasilha_barro": {"nome": "Vasilha de Barro", "kg": 0.8, "cat": "Utensílios",
		"desc": "Vasilha funda de barro feita no torno. Para guardar comida, sementes ou água."},
	"bacia_barro": {"nome": "Bacia de Barro", "kg": 2.0, "cat": "Utensílios",
		"desc": "Bacia larga e baixa de barro feita no torno. Para cozinhar, lavar e misturar."},
	"moringa_barro": {"nome": "Cabaça de Barro (Moringa)", "kg": 1.4, "cat": "Utensílios",
		"desc": "Moringa de barro vazia: barriga redonda e gargalo fino. Encha na beira de uma lagoa, rio ou nascente (água doce; do mar não): \"Encher a cabaça\"."},
	"moringa_agua": {"nome": "Cabaça com Água do Rio", "kg": 3.4, "cat": "Utensílios", "dur": 8,
		"desc": "Moringa com água da lagoa, rio ou nascente, SEM FILTRAR (uns 2 litros, 8 goles). Mata a sede, mas pode ter bactérias e sujeira: beber dela pode trazer doença. USAR bebe um gole."},
	"moringa_limpa": {"nome": "Cabaça com Água Filtrada", "kg": 3.4, "cat": "Utensílios", "dur": 8,
		"desc": "Moringa com água que passou pela peneira de água (pedrinhas, carvão e areia): limpa e segura para beber (uns 2 litros, 8 goles). USAR bebe um gole."},
	"fruto_buriti": {"nome": "Fruto de Buriti", "kg": 0.06, "cat": "Comida", "fome": 7, "sede": 2,
		"desc": "Fruto do buriti (casquinha de escamas vermelhas, polpa amarela e gordurosa). Cai maduro no pé, mais nas chuvas (dezembro a junho). USAR come."},
	"fruto_bacaba": {"nome": "Bacaba", "kg": 0.08, "cat": "Comida", "fome": 6, "sede": 3,
		"desc": "Punhado de frutinhos de bacaba (roxo quase preto), caídos no pé da palmeira de outubro a dezembro. USAR come."},
	"taia": {"nome": "Batata de Jararaca-taia", "kg": 0.25, "cat": "Itens Médicos",
		"desc": "A batata da jararaca-taia (a planta da sombra da mata com o talo pintado igual pele de cobra). O povo da mata usa contra picada de cobra. No craft: 2 batatas viram o remédio."},
	"remedio_cobra": {"nome": "Remédio de Jararaca-taia", "kg": 0.2, "cat": "Itens Médicos",
		"desc": "Batata de jararaca-taia ralada e amassada. Picado de cobra: USAR na hora (o veneno mata em pouco tempo). Ande sempre com um."},
	"capim_seco": {"nome": "Capim Seco", "kg": 0.15, "cat": "Recursos",
		"desc": "Maço de capim seco (colhido das touceiras quando secam, no fim do mês). A isca para o fogo pegar e a liga do barro do reboco."},
	"vareta": {"nome": "Vareta de Pau", "kg": 0.1, "cat": "Recursos", "dur": 3,
		"desc": "Vareta reta de galho. Gira no arco de fogo, em cima da ripa, até sair a brasa (gasta: dá umas 3 fogueiras)."},
	"arco_fogo": {"nome": "Arco de Fogo", "kg": 0.4, "cat": "Ferramentas", "dur": 12,
		"desc": "Arco de galho com o cipó esticado. USAR: com uma vareta, uma ripa (a base) e capim seco, faz fogo girando a vareta."},
	"lenha": {"nome": "Lenha", "kg": 1.2, "cat": "Recursos",
		"desc": "Acha de lenha rachada com o machado no cepo. Para a fogueira (e o carvão)."},
	"tela_fibra": {"nome": "Tela de Fibra", "kg": 0.3, "cat": "Recursos",
		"desc": "Peneira trançada de fibra de buriti. Vai por cima da areia na peneira de água: segura as folhas e a sujeira grossa."},
	"carvao": {"nome": "Carvão", "kg": 0.2, "cat": "Recursos",
		"desc": "Carvão de madeira (sai da fogueira). Na peneira de água tira as impurezas e o mau cheiro."},
	"garrafa_barro": {"nome": "Garrafa de Barro", "kg": 1.2, "cat": "Utensílios",
		"desc": "Garrafa alta e estreita de barro, para levar água."},
	"filtro_barro": {"nome": "Filtro de Barro", "kg": 3.5, "cat": "Utensílios",
		"desc": "Pote alto de barro com tampa, para guardar e filtrar a água de beber."},
	"argila_limpa": {"nome": "Argila Limpa", "kg": 2.0, "cat": "Recursos",
		"desc": "Bola de argila sem pedrinhas, raízes nem folhas (limpa à mão na mesa de argila). Pronta para modelar e fabricar."},
	"fibra_buriti": {"nome": "Fibra de Buriti", "kg": 0.25, "cat": "Recursos",
		"desc": "Fibra tirada do talo do buriti na desfibradeira (a \"seda\" do buriti). Forte e leve: serve para cordas, redes e trançados."},
	"talo_buriti": {"nome": "Talo de Buriti", "kg": 1.1, "cat": "Recursos",
		"desc": "O talo comprido da folha do buriti, cortado nas duas pontas. Dele saem as fibras (a seda do buriti) para cordas e trançados."},
	"folha_buriti_seca": {"nome": "Folha Seca de Buriti", "kg": 0.8, "cat": "Recursos",
		"desc": "Folha velha do buriti que secou e caiu sozinha. Palha marrom e leve, boa para cobrir e acender fogo."},
	"folha_buriti": {"nome": "Folha de Buriti", "kg": 2.5, "cat": "Recursos",
		"desc": "Folha grande em leque do buriti, com o talo. Serve para cobrir telhado, fazer palha e trançado."},
	"pino": {"nome": "Pino de Madeira", "kg": 0.03, "cat": "Recursos",
		"desc": "Pino roliço lascado de uma mata-junta (ripa), com a ponta afinada. Batido com a marreta num furo, prende uma madeira na outra."},
	"ripa": {"nome": "Ripa", "kg": 0.4, "cat": "Recursos",
		"desc": "Mata-junta: tira fina e reta de madeira, rachada com o machado de uma tábua pequena. 12 delas fazem a parede do balde."},
	"cunha": {"nome": "Cunha de Pedra", "kg": 0.6, "cat": "Ferramentas",
		"desc": "Pedra trabalhada grossa atrás e com fio reto na frente. Batida com a marreta, abre a tora ao meio no comprido (precisa de 3)."},
	"pedra_marreta": {"nome": "Pedra de Marreta", "kg": 1.6, "cat": "Recursos",
		"desc": "Pedra trabalhada grossa e comprida: a cabeça da marreta. Feita modelando pedra."},
	"marreta": {"nome": "Marreta de Pedra", "kg": 2.2, "cat": "Ferramentas",
		"desc": "Pedra pesada amarrada com cipó num cabo de galho. Bate nas cunhas para rachar a tora.", "ferramenta": true, "dur": 250},
	"raiz_timbo": {"nome": "Raiz de Timbó", "kg": 0.3, "cat": "Recursos",
		"desc": "Raiz do timbó, cipó da beira da mata. Amassada, solta um veneno forte (o mesmo que os índios usam para pescar) que mata os cupins."},
	"veneno_timbo": {"nome": "Veneno de Timbó", "kg": 0.5, "cat": "Itens Médicos",
		"desc": "Raiz de timbó amassada e misturada. Tem rotenona: passada na madeira, mata na hora os cupins que estão nela. Mas se desfaz no sol e na chuva: protege só uns 45 dias."},
	"semente_andiroba": {"nome": "Semente de Andiroba", "kg": 0.03, "cat": "Recursos",
		"desc": "Semente da andirobeira, árvore grande de chão úmido. Os frutos (ouriços) caem na época das chuvas e abrem no chão. A semente é cheia de óleo amargo."},
	"oleo_andiroba": {"nome": "Óleo de Andiroba", "kg": 0.4, "cat": "Itens Médicos",
		"desc": "Óleo amargo tirado das sementes (cozidas, deixadas descansar e amassadas até o óleo escorrer). Passado na madeira, entra nela e espanta os cupins por uns 2 anos."},
	"tabua": {"nome": "Tábua Pequena", "kg": 1.2, "cat": "Recursos",
		"desc": "Pedaço de tábua rachada, serrado na forquilha. COLOCAR no chão e rachar com o machado tira as ripas (mata-juntas) do balde.", "colocar": true},
	"banda": {"nome": "Banda de Tora", "kg": 0.0, "cat": "Recursos",
		"desc": "Metade de uma tora rachada no comprido com cunhas."},
	"hematita": {"nome": "Hematita", "kg": 2.0, "cat": "Recursos",
		"desc": "Minério de ferro vermelho-escuro, pesado; riscado numa pedra deixa um traço vermelho. Achado cavando nas faixas de rocha antiga das serras. Vai ser fundido para tirar ferro."},
	"magnetita": {"nome": "Magnetita", "kg": 2.4, "cat": "Recursos",
		"desc": "Minério de ferro preto e muito pesado, que puxa ferro (é magnético). Fica mais fundo que a hematita, nas mesmas faixas de rocha e no contato do granito."},
	"goetita": {"nome": "Goethita", "kg": 1.6, "cat": "Recursos",
		"desc": "Minério de ferro amarelo-amarronzado (deixa traço amarelo), formado quando a chuva altera a rocha por muito tempo. Fica na couraça dos platôs, nos brejos e em cima dos veios de cobre."},
	"silex": {"nome": "Nódulo de Sílex", "kg": 1.2, "cat": "Recursos",
		"desc": "Pederneira: pedra duríssima de sílica que nasce em camadas dentro do calcário. Quebrada, dá lascas muito afiadas; batida contra pirita ou aço solta faísca."},
	"lasca_silex": {"nome": "Lasca de Sílex", "kg": 0.08, "cat": "Recursos",
		"desc": "Fragmento afiado de sílex: faca, raspador, ponta de lança e de flecha, e para trabalhar madeira."},
	"malaquita": {"nome": "Malaquita", "kg": 1.2, "cat": "Recursos",
		"desc": "Minério de cobre verde, com faixas. Forma-se perto da superfície, onde a chuva e o ar alteraram um veio de cobre. Fundido, dá cobre."},
	"calcopirita": {"nome": "Calcopirita", "kg": 1.6, "cat": "Recursos",
		"desc": "Minério de cobre amarelo-latão, brilhante, das partes fundas dos veios (onde a água da chuva não chegou). Precisa ser torrado e fundido."},
	"balde": {"nome": "Balde de Madeira", "kg": 2.8, "cat": "Equipamentos",
		"desc": "Ripas em volta de um fundo redondo, apertadas com aros de cipó. Alça de cipó trançado. USAR: segura pela alça. Com ele no chão, a pá despeja terra ou argila dentro (cabe uns 24 litros)."},
}

const CATEGORIAS := ["Tudo", "Armas", "Munição", "Equipamentos", "Ferramentas", "Construção", "Recursos", "Itens Médicos", "Diversos"]

## Receitas que dá para fazer com as mãos (sem bancada).
const RECEITAS_MAO := [
	{"id": "machado", "qtd": 1, "ingredientes": [["pedra_machado", 1], ["galho", 1], ["cipo", 2]]},
	{"id": "cavadeira", "qtd": 1, "ingredientes": [["pedra_cavadeira", 1], ["galho", 1], ["cipo", 3]]},
	{"id": "pa", "qtd": 1, "ingredientes": [["pedra_pa", 1], ["galho", 1], ["cipo", 2]]},
	{"id": "enxada", "qtd": 1, "ingredientes": [["pedra_enxada", 1], ["galho", 1], ["cipo", 2]]},
	{"id": "serra", "qtd": 1, "ingredientes": [["lamina_serra", 1], ["galho", 1], ["cipo", 1]]},
	{"id": "forquilha", "qtd": 1, "ingredientes": [["galho", 2], ["cipo", 2]]},
	{"id": "cipo_trancado", "qtd": 1, "ingredientes": [["cipo", 3]]},
	{"id": "tela_fibra", "qtd": 1, "ingredientes": [["fibra_buriti", 6]]},
	{"id": "vareta", "qtd": 1, "ingredientes": [["galho", 1]]},
	{"id": "remedio_cobra", "qtd": 1, "ingredientes": [["taia", 2]]},
	{"id": "arco_fogo", "qtd": 1, "ingredientes": [["galho", 1], ["cipo", 2]]},
	{"id": "marreta", "qtd": 1, "ingredientes": [["pedra_marreta", 1], ["galho", 1], ["cipo", 2]]},
	{"id": "veneno_timbo", "qtd": 1, "ingredientes": [["raiz_timbo", 3]]},
	{"id": "oleo_andiroba", "qtd": 1, "ingredientes": [["semente_andiroba", 6]]},
	{"id": "lasca_silex", "qtd": 3, "ingredientes": [["silex", 1]]},
	{"id": "pino", "qtd": 2, "ingredientes": [["ripa", 1]]},
	{"id": "faca", "qtd": 1, "ingredientes": [["lamina_faca", 1], ["galho", 1], ["cipo", 1]]},
	{"id": "furador", "qtd": 1, "ingredientes": [["ponta_pedra", 1], ["galho", 1], ["cipo", 1]]},
	{"id": "balde", "qtd": 1, "ingredientes": [["ripa", 12], ["rodela", 1], ["cipo", 6], ["cipo_trancado", 1]]},
]


## Dá para pôr no chão escolhendo o lugar (com a prévia transparente)?
static func colocavel(id: String) -> bool:
	return bool(ITENS.get(id, {}).get("colocar", false))


## Quantos usos a ferramenta aguenta (0 = não gasta).
static func dur_max(id: String) -> int:
	return int(ITENS.get(id, {}).get("dur", 0))


static func nome(id: String) -> String:
	return str(ITENS.get(id, {}).get("nome", id))


static func kg(id: String) -> float:
	return float(ITENS.get(id, {}).get("kg", 0.0))


static func kg_txt(v: float) -> String:
	if v < 0.1 and v > 0.0:
		return ("%.3f" % v).replace(".", ",")
	return ("%.1f" % v).replace(".", ",")
