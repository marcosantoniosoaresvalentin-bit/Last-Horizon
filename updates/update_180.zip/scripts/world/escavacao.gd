extends Node3D
## Escavação com a pá: a terra do próprio chão sai de onde a pá bate e vai para onde
## o jogador joga. Dá para moldar o terreno do jeito que quiser (valas, tanques para
## peixe, rampas, montes).
##
## O chão normal tem pontos a cada 2,5 m, grosso demais para a pá. Por cima dele há uma
## grade fina (25 cm) só onde a terra foi mexida: cada ponto guarda quanto o chão desceu
## (cavado) ou subiu (terra jogada). Ali o chão normal some (máscara) e é desenhado este
## chão de terra mexida no lugar.

const RES := 0.2                # tamanho de cada quadradinho da grade (m)
const CH := 16                  # quadradinhos por bloco (4 m)
const MAX_DEPTH := 10.0
const DIG_R := 0.36             # raio da pá de terra
const DIG_D := 0.22             # quanto a pá entra na terra (m): fundo quase reto, parede íngreme
const REPOSE := 0.75            # terra solta escorre se o desnível passar disso por quadradinho (≈37°)

var tint_fn := Callable()       # (x, y, z) -> Color: minério à vista no buraco (a = quanto)
var clay := {}                  # Vector2i -> true: monte feito de argila despejada
var d := {}                     # Vector2i (ponto da grade) -> quanto subiu (+) ou desceu (-) (m)
var mask_tex: ImageTexture
var _mask: Image
var _jogo: Node
var _chunks := {}               # Vector2i (bloco) -> MeshInstance3D
var _mat: Material
var _mw := 0
var _mh := 0


func build(jogo: Node, soil_mat: Material, save_path := "") -> void:
	_jogo = jogo
	_mat = soil_mat
	_mw = int(jogo.MundoSim.W * jogo.CELL / RES)
	_mh = int(jogo.MundoSim.H * jogo.CELL / RES)
	_mask = Image.create(_mw, _mh, false, Image.FORMAT_R8)
	if save_path != "":
		_load(save_path)
	for k in d:
		_mark(k)
	mask_tex = ImageTexture.create_from_image(_mask)
	var keys := {}
	for k in d:
		keys[_chunk_of(k)] = true
	for ck in keys:
		_rebuild_chunk(ck)


# ================== ALTURA ==================

func _v(k: Vector2i) -> float:
	return float(d.get(k, 0.0))


## Quanto o chão subiu/desceu num ponto qualquer (entre os pontos da grade).
func delta_at(x: float, z: float) -> float:
	var fx := x / RES
	var fz := z / RES
	var ix := floori(fx)
	var iz := floori(fz)
	var tx := fx - ix
	var tz := fz - iz
	var a := lerpf(_v(Vector2i(ix, iz)), _v(Vector2i(ix + 1, iz)), tx)
	var b := lerpf(_v(Vector2i(ix, iz + 1)), _v(Vector2i(ix + 1, iz + 1)), tx)
	return lerpf(a, b, tz)


## Altura do chão de verdade (com o que foi cavado ou aterrado).
func ground_at(x: float, z: float) -> float:
	return _jogo.surface_at(x, z) + delta_at(x, z)


# ================== CAVAR E JOGAR TERRA ==================

## Uma pá de terra em c: o chão desce ali (mais no meio). Devolve o volume tirado (m³).
func dig(c: Vector3) -> float:
	var vol := 0.0
	var touched := {}
	var r := int(ceil(DIG_R * 1.2 / RES))
	var cx := roundi(c.x / RES)
	var cz := roundi(c.z / RES)
	for ix in range(cx - r, cx + r + 1):
		for iz in range(cz - r, cz + r + 1):
			var p := Vector2(ix * RES, iz * RES)
			var dist := p.distance_to(Vector2(c.x, c.z))
			var k := Vector2i(ix, iz)
			# a beira de cada pá é irregular (torrão que sai junto ou fica)
			var wob := 1.0 + 0.18 * sin(atan2(p.y - c.z, p.x - c.x) * 3.0 + c.x * 7.0 + c.z * 5.0)
			var u := clampf(dist / (DIG_R * wob), 0.0, 1.0)
			if u >= 1.0:
				continue
			var amount := DIG_D * (1.0 - pow(u, 4.0))
			var now := _v(k)
			var nv := maxf(now - amount, -MAX_DEPTH)
			vol += (now - nv) * RES * RES
			d[k] = nv
			touched[k] = true
	_changed(touched)
	return vol


## Joga a terra (vol, m³) em c: o chão sobe ali; terra solta escorre se ficar em pé demais.
func dump(c: Vector3, vol: float, tipo := "terra") -> void:
	var touched := {}
	var r := int(ceil(DIG_R / RES))
	var cx := roundi(c.x / RES)
	var cz := roundi(c.z / RES)
	var ws := {}
	var wsum := 0.0
	for ix in range(cx - r, cx + r + 1):
		for iz in range(cz - r, cz + r + 1):
			var dist := Vector2(ix * RES, iz * RES).distance_to(Vector2(c.x, c.z))
			if dist > DIG_R:
				continue
			var w := 1.0 - pow(dist / DIG_R, 2.0)
			ws[Vector2i(ix, iz)] = w
			wsum += w
	for k in ws:
		d[k] = _v(k) + vol * float(ws[k]) / wsum / (RES * RES)
		touched[k] = true
	_slump(touched)
	for k in touched:
		if _v(k) > 0.004:
			if tipo == "argila":
				clay[k] = true
			else:
				clay.erase(k)        # terra por cima cobre a argila
	_changed(touched)


## Abre (depth > 0) ou fecha (depth < 0) uma cova no meio do monte em c: a terra do
## ponto do meio vai para os 8 em volta (o mesmo volume). Devolve quanto desceu o meio.
func crater(c: Vector3, depth: float) -> float:
	var k0 := Vector2i(roundi(c.x / RES), roundi(c.z / RES))
	var mv := depth
	if depth > 0.0:
		mv = minf(depth, maxf(0.0, _v(k0) * 0.75 - 0.004))
	if absf(mv) < 0.0005:
		return 0.0
	var touched := {k0: true}
	d[k0] = _v(k0) - mv
	for ox in [-1, 0, 1]:
		for oz in [-1, 0, 1]:
			if ox == 0 and oz == 0:
				continue
			var k := k0 + Vector2i(ox, oz)
			d[k] = _v(k) + mv / 8.0
			touched[k] = true
	_changed(touched)
	return mv


## Tira terra de um monte (o barro que foi para o balde): a parte que subiu, num raio
## r de c, fica f vezes a altura (0 = o monte some).
func scale_pile(c: Vector3, r: float, f: float) -> void:
	var touched := {}
	var n := int(ceil(r / RES)) + 1
	var cx := roundi(c.x / RES)
	var cz := roundi(c.z / RES)
	for ix in range(cx - n, cx + n + 1):
		for iz in range(cz - n, cz + n + 1):
			var k := Vector2i(ix, iz)
			if _v(k) <= 0.0 or Vector2(ix * RES - c.x, iz * RES - c.z).length() > r + RES * 0.5:
				continue
			d[k] = _v(k) * f
			touched[k] = true
	if not touched.is_empty():
		_changed(touched)


## Terra solta escorre para os lados até ficar com uma inclinação que se segura.
func _slump(touched: Dictionary) -> void:
	var lim := REPOSE * RES
	var todo := touched.keys()
	var it := 0
	while not todo.is_empty() and it < 4000:
		it += 1
		var k: Vector2i = todo.pop_back()
		var hk := _v(k)
		for nb in [Vector2i(1, 0), Vector2i(-1, 0), Vector2i(0, 1), Vector2i(0, -1)]:
			var n: Vector2i = k + nb
			var diff := hk - _v(n)
			if diff > lim:
				var move := (diff - lim) * 0.5
				d[k] = _v(k) - move
				d[n] = _v(n) + move
				hk = _v(k)
				touched[n] = true
				todo.append(n)


func _changed(touched: Dictionary) -> void:
	var cks := {}
	for k in touched:
		if absf(_v(k)) < 0.002:
			d.erase(k)
		_mark(k)
		# os blocos vizinhos também (o ponto da grade fica na borda de até 4 blocos)
		for ox in [-2, -1, 0, 1]:
			for oz in [-2, -1, 0, 1]:
				cks[_chunk_of(k + Vector2i(ox, oz))] = true
	_basins_dirty = true
	if mask_tex:
		mask_tex.update(_mask)
	for ck in cks:
		_rebuild_chunk(ck)


## Os quadradinhos em volta de um ponto mexido ficam marcados (o chão normal some ali).
func _mark(k: Vector2i) -> void:
	for o in [Vector2i(0, 0), Vector2i(-1, 0), Vector2i(0, -1), Vector2i(-1, -1)]:
		var c: Vector2i = k + o
		if c.x < 0 or c.y < 0 or c.x >= _mw or c.y >= _mh:
			continue
		var any := false
		for q in [Vector2i(0, 0), Vector2i(1, 0), Vector2i(0, 1), Vector2i(1, 1)]:
			if d.has(c + q):
				any = true
				break
		_mask.set_pixel(c.x, c.y, Color(1, 0, 0) if any else Color(0, 0, 0))


func _chunk_of(k: Vector2i) -> Vector2i:
	return Vector2i(floori(float(k.x) / CH), floori(float(k.y) / CH))


# ================== DESENHO ==================

## O chão de terra mexida de um bloco: só os quadradinhos mexidos, colados no chão normal.
func _rebuild_chunk(ck: Vector2i) -> void:
	if _chunks.has(ck) and is_instance_valid(_chunks[ck]):
		_chunks[ck].free()
	_chunks.erase(ck)
	var st := SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	var any := false
	var x0 := ck.x * CH
	var z0 := ck.y * CH
	for ix in range(x0, x0 + CH):
		for iz in range(z0, z0 + CH):
			var c := Vector2i(ix, iz)
			if ix < 0 or iz < 0 or ix >= _mw or iz >= _mh or not _near_mark(c):
				continue
			any = true
			var ps := []
			var cs := []
			for q in [Vector2i(0, 0), Vector2i(1, 0), Vector2i(1, 1), Vector2i(0, 1)]:
				var k: Vector2i = c + q
				var x := k.x * RES
				var z := k.y * RES
				var dv := _v(k)
				# um tiquinho abaixo: na borda fica por baixo do chão normal (que é recortado redondo)
				# (onde não mexeu, bem mais abaixo: nas dobras do terreno a malha fina não pode aparecer por cima)
				ps.append(Vector3(x, _jogo.surface_at(x, z) + dv - (0.015 if absf(dv) > 0.002 else 0.08), z))
				var sc := _soil_color(dv, k)
				if dv > 0.002 and clay.has(k):
					var cc := Color(0.42, 0.21, 0.13).darkened((absi(hash(k)) % 100) * 0.0015)   # monte de argila
					sc = sc.lerp(cc, smoothstep(0.004, 0.05, dv))
				if dv < -0.002 and tint_fn.is_valid():
					# o que a pá deixou à vista: minério, sílex ou rocha alterada na parede do buraco
					var tc: Color = tint_fn.call(x, _jogo.surface_at(x, z) + dv, z)
					if tc.a > 0.0:
						sc = sc.lerp(Color(tc.r, tc.g, tc.b).darkened(0.4 * smoothstep(0.1, 2.5, -dv)), tc.a)
				cs.append(sc)
			for tri in [[0, 1, 2], [0, 2, 3]]:
				for t in tri:
					st.set_color(cs[t])
					st.add_vertex(ps[t])
	if not any:
		return
	st.generate_normals()
	var mi := MeshInstance3D.new()
	mi.mesh = st.commit()
	mi.material_override = _mat
	add_child(mi)
	_chunks[ck] = mi


## Quadradinho mexido ou vizinho de um mexido (a terra é desenhada com uma margem).
func _near_mark(c: Vector2i) -> bool:
	for ox in [-1, 0, 1]:
		for oz in [-1, 0, 1]:
			var q: Vector2i = c + Vector2i(ox, oz)
			if q.x >= 0 and q.y >= 0 and q.x < _mw and q.y < _mh and _mask.get_pixel(q.x, q.y).r > 0.5:
				return true
	return false


## Cor da terra: em cima o húmus escuro, mais fundo a terra amarelada/avermelhada com
## faixas de camadas; terra jogada (solta) mais clara e grumosa.
static func _soil_color(dv: float, k: Vector2i) -> Color:
	var h := absi(hash(k)) % 100
	if dv >= 0.0:
		return Color(0.33, 0.24, 0.16).darkened(h * 0.0015)
	var depth := -dv
	var c := Color(0.2, 0.15, 0.1).lerp(Color(0.38, 0.27, 0.17), smoothstep(0.05, 0.4, depth))
	c = c.lerp(Color(0.45, 0.3, 0.18), smoothstep(1.0, 3.0, depth))
	c = c.darkened(0.06 * float(int(depth * 10.0) % 2) + h * 0.0012)
	return c.darkened(0.45 * smoothstep(0.1, 2.5, depth))       # o fundo pega menos luz


# ================== SALVAR ==================

func save(path: String) -> void:
	var out := []
	for k in d:
		out.append([k.x, k.y, snappedf(float(d[k]), 0.001)])
	var f := FileAccess.open(path, FileAccess.WRITE)
	if f:
		var cl := []
		for k in clay:
			cl.append([k.x, k.y])
		var wat := []
		for key in water:
			wat.append([key.x, key.y, snappedf(float(water[key]), 0.0001)])
		f.store_string(JSON.stringify({"versao": 1, "res": RES, "pontos": out, "argila": cl, "agua": wat}))
		f.close()


func _load(path: String) -> void:
	if not FileAccess.file_exists(path):
		return
	var j = JSON.parse_string(FileAccess.get_file_as_string(path))
	if not j is Dictionary:
		return
	var r0 := float(j.get("res", 0.25))
	for e in j.get("pontos", []):
		var k := Vector2i(roundi(float(e[0]) * r0 / RES), roundi(float(e[1]) * r0 / RES))
		d[k] = minf(float(d.get(k, 0.0)), float(e[2])) if float(e[2]) < 0.0 else maxf(float(d.get(k, 0.0)), float(e[2]))
	if is_equal_approx(r0, RES):
		for e in j.get("argila", []):
			clay[Vector2i(int(e[0]), int(e[1]))] = true
		for e in j.get("agua", []):
			_basin_of[Vector2i(int(e[0]), int(e[1]))] = Vector2i(int(e[0]), int(e[1]))
			water[Vector2i(int(e[0]), int(e[1]))] = float(e[2])


# ================== ÁGUA NOS BURACOS ==================
# Cada buraco (bacia) guarda um volume de água. A chuva enche (a água que cai em volta
# também escorre para dentro), o sol e a terra secam. Buraco que passa do nível do mar
# enche de água do mar pelo chão, até o nível do mar.

var sea_m := -1e9                # nível do mar (m)
var water := {}                  # chave da bacia (ponto mais fundo) -> volume (m³)
var _basin_of := {}              # ponto -> chave da bacia
var _basins := {}                # chave -> {pts: [pontos], rim (m), low (m), level (m)}
var _water_mi: MeshInstance3D = null
var water_mat: Material
var _basins_dirty := true
var _murk_old := {}
## (x, z) -> nível da água doce (rio, lagoa) que está em cima do chão ali, ou -1e9.
var rio_fn := Callable()
## (de, para, m³): de == para: a água que os buracos puxaram da lagoa (+) ou devolveram
## (-); de != para: a lagoa escoando pela valeta até a ponta dela.
var agua_fn := Callable()
const VERTEDOURO_C := 1.7        # vazão por cima da borda (m^0,5/s): Q = C · largura · altura^1,5
const VERTEDOURO_L := 0.6        # largura da boca da valeta (m)
const RIO_TAU := 0.12            # horas do jogo: buraco aberto no rio enche depressa
const LENCOL_TAU := 1.5          # horas do jogo: perto do rio a água vem minando pelo chão
const LENCOL_R := 30.0           # até quantos metros do rio a terra fica úmida por baixo
const LENCOL_CAI := 0.04         # o lençol desce 4 cm por metro longe do rio


func _ground_k(k: Vector2i) -> float:
	return _jogo.surface_at(k.x * RES, k.y * RES) + _v(k)


var _gc := {}      # chão já calculado em cada ponto (limpo quando a terra muda)

func _gk(k: Vector2i) -> float:
	var v = _gc.get(k)
	if v == null:
		v = _ground_k(k)
		_gc[k] = v
	return v


func _find_basins() -> void:
	var old := water
	var old_of := _basin_of
	var old_n := {}     # quantos pontos tinha cada bacia antiga
	for k in old_of:
		old_n[old_of[k]] = int(old_n.get(old_of[k], 0)) + 1
	# água salva sem os pontos (carregou do arquivo): fica toda no ponto mais fundo dela
	for key in old:
		if not old_n.has(key) or int(old_n[key]) <= 1:
			old_n[key] = 1
	_murk_old = {}
	for key in _basins:
		_murk_old[key] = float(_basins[key].get("murk", 0.85))
	_basins = {}
	_basin_of = {}
	_gc = {}
	water = {}
	var seen := {}
	for k0 in d:
		if seen.has(k0) or _v(k0) > -0.03:
			continue
		var pts := []
		var todo := [k0]
		var low_k: Vector2i = k0
		while not todo.is_empty():
			var k: Vector2i = todo.pop_back()
			if seen.has(k) or _v(k) > -0.03:
				continue
			seen[k] = true
			pts.append(k)
			if _gk(k) < _gk(low_k):
				low_k = k
			for nb in [Vector2i(1, 0), Vector2i(-1, 0), Vector2i(0, 1), Vector2i(0, -1)]:
				todo.append(k + nb)
		# borda: o ponto mais baixo em volta do buraco (por ali a água transborda)
		var rim := 1e9
		var borda := {}
		for k in pts:
			for nb in [Vector2i(1, 0), Vector2i(-1, 0), Vector2i(0, 1), Vector2i(0, -1)]:
				var n: Vector2i = k + nb
				if not seen.has(n) or _v(n) > -0.03:
					rim = minf(rim, _gk(n))
					borda[n] = true
		var vol := 0.0
		var mk := 0.85                   # buraco novo: a água que entrar vem barrenta
		for k in pts:
			var ob = old_of.get(k)
			if ob != null and old.has(ob):
				vol += float(old[ob]) / maxf(float(old_n.get(ob, 1)), 1.0)
				mk = float(_murk_old.get(ob, mk))
			_basin_of[k] = low_k
		var gs := PackedFloat32Array()
		for k in pts:
			gs.append(_gk(k))
		gs.sort()
		# o centro (para achar o rio mais perto) e a borda (uns pontos, para ver se abriu no rio)
		var cx := 0.0
		var cz := 0.0
		for k in pts:
			cx += k.x
			cz += k.y
		var bl: Array = borda.keys()
		var passo := maxi(1, bl.size() / 60)
		var amostra := []
		for i in range(0, bl.size(), passo):
			amostra.append(bl[i])
		_basins[low_k] = {"pts": pts, "g": gs, "rim": rim, "low": _gk(low_k), "level": -1e9, "murk": mk,
			"c": Vector2(cx / pts.size() * RES, cz / pts.size() * RES), "borda": amostra}
		water[low_k] = vol
	_basins_dirty = false


## Nível da água de uma bacia com esse volume (enche de baixo para cima).
func _level_for(b: Dictionary, vol: float) -> float:
	var g: PackedFloat32Array = b.g
	var n := g.size()
	if vol <= 0.0 or n == 0:
		return float(b.low) - 1.0
	var t := vol / (RES * RES)
	var pre := 0.0
	for i in n:
		pre += g[i]
		var nxt: float = g[i + 1] if i + 1 < n else 1e9
		var L := (t + pre) / float(i + 1)
		if L <= nxt:
			return minf(L, float(b.rim))
	return float(b.rim)


func _vol_at(b: Dictionary, level: float) -> float:
	var g: PackedFloat32Array = b.g
	var v := 0.0
	for x in g:
		if x >= level:
			break
		v += level - x
	return v * RES * RES


## Passa o tempo: chuva enche, sol seca, mar entra pelo chão nos buracos abaixo dele.
func water_tick(hours: float, rain_mmh: float, evap_mmh: float) -> void:
	var redraw := false
	if _basins_dirty:
		_find_basins()
		redraw = true
	if _basins.is_empty():
		if redraw:
			_draw_water()
		return
	for key in _basins:
		var b: Dictionary = _basins[key]
		var area := float((b.pts as Array).size()) * RES * RES
		var vol := float(water.get(key, 0.0))
		var full := _vol_at(b, float(b.rim))
		vol += rain_mmh / 1000.0 * hours * area * 2.5        # a chuva em volta escorre para dentro
		var lvl := _level_for(b, vol)
		var wet_area := 0.0
		for x in (b.g as PackedFloat32Array):
			if x >= lvl:
				break
			wet_area += RES * RES
		vol -= evap_mmh / 1000.0 * hours * wet_area   # sol e a terra chupando
		if float(b.low) < sea_m:
			vol = maxf(vol, _vol_at(b, minf(sea_m, float(b.rim))))   # o mar entra pelo chão
		if rio_fn.is_valid():
			vol = _agua_do_rio(b, vol, hours)
		# o barro da água: a do rio entra clara, a que mina pelo chão vem filtrada; a chuva
		# escorrendo turva; parada, o barro assenta no fundo devagar
		var mk := float(b.get("murk", 0.85))
		var alvo_mk := 0.3
		var tau := 8.0
		if b.get("fonte", "") == "rio":
			alvo_mk = 0.15
			tau = 0.3
		elif rain_mmh > 0.5:
			alvo_mk = 0.85
			tau = 1.0
		elif b.get("fonte", "") == "lencol":
			alvo_mk = 0.2
			tau = 4.0
		mk += (alvo_mk - mk) * (1.0 - exp(-hours / tau))
		if absf(mk - float(b.get("murk_d", -1.0))) > 0.05:
			b.murk_d = mk
			redraw = true
		b.murk = mk
		vol = clampf(vol, 0.0, full)
		water[key] = vol
		var nl: float = _level_for(b, vol) if vol > 0.0005 else -1e9
		if absf(nl - float(b.level)) > 0.004:
			b.level = nl
			redraw = true
	if redraw:
		_draw_water()


## O rio e o lençol: buraco aberto até a água do rio enche até o nível dele (a valeta
## leva a água por onde for cavada, se o fundo dela estiver abaixo do rio) e esvazia
## de volta se ficar acima. Buraco fechado perto do rio, mais fundo que o lençol, enche
## devagar minando pelo chão (o poço / a cacimba).
func _agua_do_rio(b: Dictionary, vol: float, hours: float) -> float:
	# 1) aberto no rio: algum ponto da borda (ou do fundo) está debaixo da água do rio
	var Lr := -1e9
	var rim_seco := 1e9
	var boca := Vector2.ZERO          # onde o buraco encosta na água do rio/lagoa
	var secos := []
	for k in b.borda:
		var x := float(k.x) * RES
		var z := float(k.y) * RES
		var lv: float = rio_fn.call(x, z)
		if lv > _gk(k) + 0.01:
			if lv > Lr:
				Lr = lv
				boca = Vector2(x, z)
		else:
			rim_seco = minf(rim_seco, _gk(k))
			secos.append(k)
	if Lr < -1e8:
		# cavado dentro do próprio rio
		var kl := _basin_low_k(b)
		var lv2: float = rio_fn.call(float(kl.x) * RES, float(kl.y) * RES)
		if lv2 > float(b.low):
			Lr = lv2
			boca = Vector2(kl.x, kl.y) * RES
	if Lr > float(b.low):
		b.fonte = "rio"
		var alvo := _vol_at(b, minf(Lr, rim_seco))
		var novo := vol + (alvo - vol) * (1.0 - exp(-hours / RIO_TAU))
		var tirou := novo - vol           # o que entrou no buraco saiu da lagoa (e volta se sair)
		# a borda seca mais baixa ficou abaixo da água: transborda por ali e escorre morro
		# abaixo (a lagoa vai escoando pela valeta até o nível dessa borda)
		# (só conta a borda longe da boca: perto dela é a própria beira da lagoa)
		var saida := 1e9
		var ps := Vector2.ZERO
		for k in secos:
			var pk := Vector2(float(k.x) * RES, float(k.y) * RES)
			if pk.distance_to(boca) > 4.0 and _gk(k) < saida:
				saida = _gk(k)
				ps = pk
		var vaza := 0.0
		if Lr > saida + 0.005:
			var h := minf(Lr - saida, 1.0)
			vaza = VERTEDOURO_C * VERTEDOURO_L * pow(h, 1.5) * hours * 3600.0
		if agua_fn.is_valid():
			if absf(tirou) > 0.0001:
				agua_fn.call(boca, boca, tirou)
			if vaza > 0.0001:
				agua_fn.call(boca, ps, vaza)          # sai pela ponta da valeta e corre morro abaixo
		return novo
	# 2) lençol: a água do rio perto vem minando pelo chão
	var wt := -1e9
	var c: Vector2 = b.c
	var passo := 5.0
	var r := ceili(LENCOL_R / passo)
	for ix in range(-r, r + 1):
		for iz in range(-r, r + 1):
			var off := Vector2(ix, iz) * passo
			var dist := off.length()
			if dist > LENCOL_R:
				continue
			var lv3: float = rio_fn.call(c.x + off.x, c.y + off.y)
			if lv3 > -1e8:
				wt = maxf(wt, lv3 - dist * LENCOL_CAI)
	b.fonte = ""
	if wt > float(b.low):
		b.fonte = "lencol"
		var alvo2 := _vol_at(b, minf(wt, float(b.rim)))
		if alvo2 > vol:
			return vol + (alvo2 - vol) * (1.0 - exp(-hours / LENCOL_TAU))
	return vol


func _basin_low_k(b: Dictionary) -> Vector2i:
	var best: Vector2i = (b.pts as Array)[0]
	for k in b.pts:
		if _gk(k) < _gk(best):
			best = k
	return best


## Nível da água no ponto (ou -1e9 se não tem água de buraco ali).
## O chão aqui é um monte de argila despejada?
func is_clay(x: float, z: float) -> bool:
	var k0 := Vector2i(roundi(x / RES), roundi(z / RES))
	for ox in range(-2, 3):
		for oz in range(-2, 3):
			var k := k0 + Vector2i(ox, oz)
			if clay.has(k) and _v(k) > 0.01:
				return true
	return false


func water_level_at(x: float, z: float) -> float:
	var k := Vector2i(roundi(x / RES), roundi(z / RES))
	var key = _basin_of.get(k)
	if key == null or not _basins.has(key):
		return -1e9
	return float(_basins[key].level)


func _draw_water() -> void:
	if _water_mi == null:
		_water_mi = MeshInstance3D.new()
		_water_mi.material_override = water_mat
		_water_mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		add_child(_water_mi)
	var st := SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	var any := false
	for key in _basins:
		var b: Dictionary = _basins[key]
		var L := float(b.level)
		if L < -1e8:
			continue
		var drawn := {}
		for k in b.pts:
			for o in [Vector2i(0, 0), Vector2i(-1, 0), Vector2i(0, -1), Vector2i(-1, -1)]:
				var c: Vector2i = k + o
				if drawn.has(c):
					continue
				drawn[c] = true
				# fundura em cada canto: na beirada vai a zero e a água some suave (as paredes cobrem o resto)
				var p := []
				var cols := []
				var wet := false
				for q in [Vector2i(0, 0), Vector2i(1, 0), Vector2i(1, 1), Vector2i(0, 1)]:
					var kk: Vector2i = c + q
					var dep := L - _gk(kk)
					wet = wet or dep > 0.0
					p.append(Vector3(kk.x * RES, L, kk.y * RES))
					cols.append(_jogo._wcol(float(b.get("murk", 0.85)), dep))
				if not wet:
					continue
				any = true
				for t in [0, 1, 2, 0, 2, 3]:
					st.set_color(cols[t])
					st.set_normal(Vector3.UP)
					st.add_vertex(p[t])
	_water_mi.mesh = st.commit() if any else null
